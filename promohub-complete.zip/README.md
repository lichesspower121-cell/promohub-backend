# PromoHub

Files:
- index.html
- style.css
- app.js
- server.py
- requirements.txt
- Procfile

## Frontend
Put `index.html`, `style.css`, and `app.js` in your GitHub Pages repository.

## Backend
Deploy the same repository (or a backend-only copy) to a Python hosting service.

Set environment variables:
- `BOT_TOKEN` = your Telegram bot token
- `TARGET_CHAT` = `@giveawayforall2`
- `FRONTEND_ORIGIN` = your exact GitHub Pages origin, for example `https://username.github.io`

Your bot must be an admin/member with permission to post in the target chat.

After backend deployment, edit `app.js`:
`const API_BASE_URL = "https://YOUR-BACKEND-URL";`

Replace it with your backend HTTPS address, without a trailing slash.

## Telegram
Open the GitHub Pages URL as a Telegram Mini App/Web App. The server validates Telegram initData before posting.

## Important behavior
- Group mode actually posts the submitted Telegram link to TARGET_CHAT.
- Users mode creates a local campaign target for 15, 20, or 100 users. It does not mass-DM Telegram users.
- Credits and campaign history are localStorage demo data. For real accounts/balances, use a database on the backend.
